package com.example.eindopdrachtjava_luciano.DAL;

import com.example.eindopdrachtjava_luciano.Model.Movie;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MovieDatabase implements Serializable {
    private static final long serialVersionUID = 1L; //
    private List<Movie> movies;

    public MovieDatabase() {
        movies = new ArrayList<>();
        movies.add(new Movie(LocalDateTime.of(2024, 10, 4, 14, 0),
                LocalDateTime.of(2024, 10, 4, 16, 30),
                "Rebel Moon - Part Two: The Scargiver", 66));
        movies.add(new Movie(LocalDateTime.of(2024, 10, 4, 14, 0),
                LocalDateTime.of(2024, 10, 4, 16, 30),
                "Rebel Moon - Part Two: The Scargiver", 44));
    }

    public void save(Movie newMovie) {
        movies.add(newMovie);
        try (FileOutputStream fos = new FileOutputStream(new File("movies.dat"));
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            for (Movie movie : movies) {
                oos.writeObject(movie);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("Het bestand kan niet worden gevonden.");
        } catch (IOException ioe) {
            System.out.println("Een andere exceptie.");
        }
    }

    public void load(){
        movies.clear();
        try (ObjectInputStream ois = new ObjectInputStream(
            new FileInputStream(new File("movies.dat")))){
            while(true){
                try{
                    Movie movie = (Movie)ois.readObject();
                    movies.add(movie);
                } catch (EOFException eofException){
                    break;
                }  catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch (FileNotFoundException fnfe){
            System.out.println("Het bestand kan niet worden gevonden.");
        } catch (IOException e){
            System.out.println("Een andere exceptie.");
        }
    }

    public List<Movie> getMovies() {
        return movies;
    }
}
