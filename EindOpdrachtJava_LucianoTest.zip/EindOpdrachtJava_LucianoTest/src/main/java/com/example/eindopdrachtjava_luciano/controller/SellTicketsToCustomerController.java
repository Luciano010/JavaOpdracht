package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.Movie;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;

public class SellTicketsToCustomerController implements Initializable, BaseController {
    private Movie selectedMovie;
    public SellTicketsToCustomerController(Movie movie) {
        this.selectedMovie = movie;
    }

    @FXML
    private GridPane seatGrid;

    @FXML
    private TextField customerNameField;

    @FXML
    private Label selectedMovieLabel;

    @FXML
    private Button sellTicketsButton;

    @FXML
    private Button sellTicketsFormButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Button manageShowingsButton;

    @FXML
    private Button viewSalaryHistoryButton;

    @FXML
    private TextArea seatsRowAndColumnTextArea;

    private List<ToggleButton> selectedSeats = new ArrayList<>();
    private Set<String> occupiedSeats = new HashSet<>();

    private void setMovieLabel(){
        selectedMovieLabel.setText(selectedMovie.toString());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadOccupiedSeats();
        setupSeatGrid();

        cancelButton.setOnAction(event -> {changeView(cancelButton, "selltickets-view.fxml", new SellTicketsController(), "Sell tickets");});
        sellTicketsFormButton.setOnAction(event -> {changeView(sellTicketsFormButton, "selltickets-view.fxml", new SellTicketsController(), "Sell tickets");});
        manageShowingsButton.setOnAction(event -> {changeView(manageShowingsButton, "manageshowing-view.fxml", new ManageShowingController(), "Manage showings");});
        //viewSalaryHistoryButton.setOnAction(event -> {changeView(viewSalaryHistoryButton, "selltickets-view.fxml", new SellTicketsController(), "Sell tickets");});

        sellTicketsButton.setOnAction(event -> {handleSellTicketsButton();});

        sellTicketsButton.setDisable(true);
        customerNameField.textProperty().addListener((observable, oldValue, newValue) -> {
            updateSellButtonState();
        });
    }

    private void loadOccupiedSeats() {
        try(BufferedReader reader = new BufferedReader(new FileReader("C:/Users/Beheerder/IdeaProjects/EindOpdrachtJava_Luciano/src/main/java/com/example/eindopdrachtjava_luciano/Service/customersDAL.txt"))) {
            String line;
            while((line = reader.readLine()) != null){
                String[] parts = line.split(",");
                if(parts.length >= 2){
                    String row = parts[0];
                    String col = parts[1];
                    occupiedSeats.add(row + "," + col);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupSeatGrid(){
        for (int row = 1; row <= 6; row++) {
            for (int col = 1; col <= 12; col++) {
                final int currentRow = row;
                final int currentCol = col;
                ToggleButton seatButton = new ToggleButton(String.valueOf(col));
                seatButton.setPrefSize(30, 30); // Set the preferred size for each button
                seatButton.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE); // Allow it to grow/shrink to fill the cell

                String seatKey = currentRow + "," + currentCol;
                if(occupiedSeats.contains(seatKey)){
                    seatButton.setStyle("-fx-background-color: red; -fx-text-fill: white;");
                    seatButton.setDisable(true);
                } else {
                    seatButton.setOnAction(event -> handleSeatSelection(seatButton, currentRow, currentCol));
                }
                seatGrid.add(seatButton, col - 1, row - 1);
            }
        }
    }


    private void handleSeatSelection(ToggleButton seatButton, int row, int col) {
        if(seatButton.isSelected()) {
            seatButton.setStyle("-fx-background-color: green; -fx-text-fill: white;");
            selectedSeats.add(seatButton);
        } else {
            seatButton.setStyle("");
            selectedSeats.remove(seatButton);
        }
        updateSelectedSeatsTextArea();
        updateSellButtonState();
    }

    private void updateSelectedSeatsTextArea(){
        StringBuilder seatText = new StringBuilder();
        for(ToggleButton seatButton : selectedSeats){
            int row = GridPane.getRowIndex(seatButton) + 1;
            int col = GridPane.getColumnIndex(seatButton) + 1;
            seatText.append(String.format("Row %d / Seat %d\n", row, col));
        }
        seatsRowAndColumnTextArea.setText(seatText.toString());
    }

    private void updateSellButtonState(){
        boolean enableButton = !selectedSeats.isEmpty() && !customerNameField.getText().trim().isEmpty();
        sellTicketsButton.setDisable(!enableButton);
        sellTicketsButton.setText("Sell " + selectedSeats.size() + " tickets");
    }

    private void handleSellTicketsButton(){
        String customerName = customerNameField.getText();
        LocalDateTime now = LocalDateTime.now();

        try (FileWriter writer = new FileWriter("C:/Users/Beheerder/IdeaProjects/EindOpdrachtJava_Luciano/src/main/java/com/example/eindopdrachtjava_luciano/Service/customersDAL.txt", true)){
            for(ToggleButton seatButton : selectedSeats){
                int row = GridPane.getRowIndex(seatButton) + 1;
                int col = GridPane.getColumnIndex(seatButton) + 1;

                writer.write(row + "," + col + "," + now.toString() + "," + selectedSeats.size() + "," + customerName + "," + selectedMovie.getStartTime() + " " + selectedMovie.getEndTime());
                seatButton.setStyle("-fx-background-color: red; -fx-text-fill: white;");
                seatButton.setDisable(true);
            }
            selectedSeats.clear();
            updateSelectedSeatsTextArea();
            updateSellButtonState();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    private void changeView(Button button, String view, BaseController controller, String title){
        try{
            Stage viewStage = (Stage) button.getScene().getWindow();
            viewStage.close();

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(view));
            fxmlLoader.setController(controller);

            Parent root = fxmlLoader.load();

            Stage newViewStage = new Stage();
            newViewStage.setTitle(title);
            newViewStage.setScene(new Scene(root));
            newViewStage.show();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }
}
