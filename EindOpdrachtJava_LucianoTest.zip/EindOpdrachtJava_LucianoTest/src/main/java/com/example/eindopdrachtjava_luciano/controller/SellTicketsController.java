package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.Movie;
import com.example.eindopdrachtjava_luciano.Service.SellTicketService;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class SellTicketsController implements Initializable, BaseController {
    private SellTicketService sellTicketsService = new SellTicketService();

    @FXML
    private TableView<Movie> tableViewManagement;

    @FXML
    private TableColumn<Movie, LocalDateTime> startColumn;

    @FXML
    private TableColumn<Movie, LocalDateTime> endColumn;

    @FXML
    private TableColumn<Movie, String> titleColumn;

    @FXML
    private TableColumn<Movie, Integer> seatsLeftColumn;

    @FXML
    private Button addShowingsButton;

    @FXML
    private Button buttonManageShowings;

    @FXML
    private Button selectSeatButton;

    @FXML
    private Label selectedLabel;

    private void changeView(Button button, String view, BaseController controller, String title){
        try{
            Stage viewStage = (Stage) button.getScene().getWindow();
            viewStage.close();

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(view));
            fxmlLoader.setController(controller);

            Parent root = fxmlLoader.load();

            Stage newViewStage = new Stage();
            newViewStage.setTitle(title);
            newViewStage.setScene(new Scene(root));
            newViewStage.show();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    private void changeLabelSelected(){
        tableViewManagement.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                selectedLabel.setText("Selected: " + newValue.getStartTime().toString() + newValue.getTitle());
                selectSeatButton.setVisible(true);
                selectSeatButton.setDisable(false);
                selectSeatButton.setOnAction(event -> {changeView(selectSeatButton, "sellticketstocustomer-view.fxml", new SellTicketsToCustomerController(newValue), "Sell Tickets");});
            }
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        startColumn.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        endColumn.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        seatsLeftColumn.setCellValueFactory(new PropertyValueFactory<>("seatsLeft"));

        ObservableList<Movie> movies = sellTicketsService.readUpcomingMovies();
        tableViewManagement.setItems(movies);
        selectSeatButton.setVisible(false);
        selectSeatButton.setDisable(true);
        changeLabelSelected();
        buttonManageShowings.setOnAction(event -> {changeView(buttonManageShowings, "manageshowing-view.fxml", new ManageShowingController(), "Manage Showings");});
    }
}
