package com.example.eindopdrachtjava_luciano.Model;

import java.time.LocalDateTime;

public class Customer {
    private int row;
    private int col;
    private LocalDateTime dateMade;
    private int numberOfTickets;
    private String customerName;
    private Movie movie;

    public Customer(int row, int col, LocalDateTime dateMade, int numberOfTickets, String customerName, Movie movie) {
        this.row = row;
        this.col = col;
        this.dateMade = dateMade;
        this.numberOfTickets = numberOfTickets;
        this.customerName = customerName;
        this.movie = movie;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public LocalDateTime getDateMade() {
        return dateMade;
    }

    public void setDateMade(LocalDateTime dateMade) {
        this.dateMade = dateMade;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public void setNumberOfTickets(int numberOfTickets) {
        this.numberOfTickets = numberOfTickets;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
}
