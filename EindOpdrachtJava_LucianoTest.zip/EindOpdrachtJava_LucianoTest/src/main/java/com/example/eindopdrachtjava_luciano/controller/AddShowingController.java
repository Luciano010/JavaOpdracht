package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.DAL.MovieDatabase;
import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.Movie;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;

import java.awt.*;
import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AddShowingController implements Initializable, BaseController, Serializable {
    private String filePath = "C:/Users/Beheerder/IdeaProjects/EindOpdrachtJava_Luciano/src/main/java/com/example/eindopdrachtjava_luciano/DAL/movies.dat";

    @FXML
    private TextField titleTextField;

    @FXML
    private DatePicker startTimeDatePicker;

    @FXML
    private TextField startTimeField;

    @FXML
    private DatePicker endTimeDatePicker;

    @FXML
    private TextField endTimeField;

    @FXML
    private Button addShowingButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Label showLabelError;

    private void onAddShowingButtonClick() {
        if(titleTextField.getText().isEmpty() || startTimeDatePicker.getValue() == null
                || startTimeField.getText().isEmpty() || endTimeDatePicker.getValue() == null
                || endTimeField.getText().isEmpty()) {
            showLabelError.setText("Please enter the correct data");
        } else {
            String title = titleTextField.getText();
            LocalDate startDate = startTimeDatePicker.getValue();
            String startTime = startTimeField.getText();
            LocalDate endDate = endTimeDatePicker.getValue();
            String endTime = endTimeField.getText();

            LocalDateTime startDateTime = parseDateTime(startDate, startTime);
            LocalDateTime endDateTime = parseDateTime(endDate, endTime);

            MovieDatabase movieDatabase = new MovieDatabase();
            movieDatabase.load();
            movieDatabase.save(new Movie(startDateTime, endDateTime, title, 0));

            changeView(addShowingButton);
        }
    }

    private LocalDateTime parseDateTime(LocalDate date, String time) {
        return LocalDateTime.of(date, LocalTime.parse(time));
    }

    public static void writeMoviesToBinaryFile(String fileName, List<Movie> movies) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(movies);
            System.out.println("Movies succesvol geschreven naar binary file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Movie> readMoviesFromBinaryFile(String fileName) {
        List<Movie> movies = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            movies = (List<Movie>) ois.readObject();
            System.out.println("Movies succesvol gelezen uit binary file.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return movies;
    }

    private void changeView(Button button){
        try{
            Stage addShowingStage = (Stage) button.getScene().getWindow();
            addShowingStage.close();

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("manageshowing-view.fxml"));
            ManageShowingController manageShowingController = new ManageShowingController();
            fxmlLoader.setController(manageShowingController);

            Parent root = fxmlLoader.load();

            Stage manageShowingStage = new Stage();
            manageShowingStage.setTitle("Manage Showing");
            manageShowingStage.setScene(new Scene(root));
            manageShowingStage.show();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    private void setPrompts(){
        titleTextField.setPromptText("Title");
        startTimeDatePicker.setPromptText("Date (DD/MM/YYYY)");
        endTimeDatePicker.setPromptText("Date (DD/MM/YYYY)");
        startTimeField.setPromptText("Time (HH:MM)");
        endTimeField.setPromptText("Time (HH:MM)");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setPrompts();
        addShowingButton.setOnAction(event -> onAddShowingButtonClick());
        cancelButton.setOnAction(event -> changeView(cancelButton));
    }
}
