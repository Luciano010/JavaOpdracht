package com.example.eindopdrachtjava_luciano.Model;

public enum Role {
    MANAGER, WERKNEMER
}
