package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.Role;
import com.example.eindopdrachtjava_luciano.Model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class DashboardController implements Initializable, BaseController {
    @FXML
    private Label labelWelcome;

    @FXML
    private Label labelLoggedRole;

    @FXML
    private Label labelCurrentDate;

    @FXML
    private Button buttonManageShowings;

    @FXML
    private Button buttonSellTickets;

    @FXML
    private Button buttonViewSalesHistory;


    private User user;

    public DashboardController(User user) {
        this.user = user;
    }

    private void checkUserRole(){
        if (!user.getRole().equals(Role.MANAGER)) {
            buttonManageShowings.setDisable(true);
            buttonManageShowings.setVisible(false);
        }
    }

    private void changeView(Button button, String view, BaseController controller, String title){
        try{
            Stage viewStage = (Stage) button.getScene().getWindow();
            viewStage.close();

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(view));
            fxmlLoader.setController(controller);

            Parent root = fxmlLoader.load();

            Stage newViewStage = new Stage();
            newViewStage.setTitle(title);
            newViewStage.setScene(new Scene(root));
            newViewStage.show();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        labelWelcome.setText("Welcome " + user.getUsername());
        labelLoggedRole.setText("You are logged in as " + user.getRole().toString());

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String formattedDate = now.format(formatter);
        labelCurrentDate.setText("The current date and time is " + formattedDate);

        checkUserRole();
        buttonManageShowings.setOnAction(event -> {changeView(buttonManageShowings, "manageshowing-view.fxml", new ManageShowingController(), "ManageShowing");});
        buttonSellTickets.setOnAction(event -> changeView(buttonSellTickets, "selltickets-view.fxml", new SellTicketsController(), "Sell Tickets"));
    }
}
