package com.example.eindopdrachtjava_luciano.Service;

import com.example.eindopdrachtjava_luciano.Model.Role;
import com.example.eindopdrachtjava_luciano.Model.User;

import java.util.ArrayList;

public class UserService {
    private ArrayList<User> users;

    public UserService() {
        users = new ArrayList<>();
        fillUsers(users);
    }

    public void fillUsers(ArrayList<User> users) {
        users.add(new User("Luciano", "welkom123", Role.MANAGER));
        users.add(new User("luc", "123", Role.WERKNEMER));
        users.add(new User("Robert", "123Welkom", Role.WERKNEMER));
    }

    public User authenticate(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }



    public void addUser(User user) {
        users.add(user);
    }
}
