package com.example.eindopdrachtjava_luciano.Service;
import com.example.eindopdrachtjava_luciano.Model.Movie;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class MovieService {
    public static void writeMoviesToBinaryFile(String fileName, List<Movie> movies) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(movies);
            System.out.println("Movies succesvol geschreven naar binary file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Movie> readMoviesFromBinaryFile(String fileName) {
        List<Movie> movies = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            movies = (List<Movie>) ois.readObject();
            System.out.println("Movies succesvol gelezen uit binary file.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return movies;
    }
}
