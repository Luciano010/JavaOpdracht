package com.example.eindopdrachtjava_luciano.Service;

import com.example.eindopdrachtjava_luciano.Model.Movie;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SellTicketService {
    private ObservableList<Movie> upcomingMovieList = FXCollections.observableArrayList();

    public ObservableList<Movie> readUpcomingMovies(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        try(BufferedReader bufferreader = new BufferedReader(new FileReader("C:/Users/Beheerder/IdeaProjects/EindOpdrachtJava_Luciano/src/main/java/com/example/eindopdrachtjava_luciano/Service/itemsDAL.txt"))){
            String line;
            while((line = bufferreader.readLine()) != null){
                String[] lines = line.split(",");

                LocalDateTime startTime = LocalDateTime.parse(lines[0], formatter);
                LocalDateTime endTime = LocalDateTime.parse(lines[1], formatter);
                String title = lines[2];
                int seatsLeft = Integer.parseInt(lines[3]);

                if(startTime.isAfter(LocalDateTime.now())){
                    Movie movie = new Movie(startTime, endTime, title, seatsLeft);
                    upcomingMovieList.add(movie);
                }
            }
        } catch (IOException e){
            e.printStackTrace();
        }
        return upcomingMovieList;
    }
}
