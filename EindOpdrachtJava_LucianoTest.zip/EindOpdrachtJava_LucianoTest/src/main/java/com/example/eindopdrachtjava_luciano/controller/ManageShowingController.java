package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.DAL.MovieDatabase;
import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.Movie;
import com.example.eindopdrachtjava_luciano.Service.BaseService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ResourceBundle;

public class ManageShowingController implements Initializable, BaseController {

    private BaseService manageShowingService = new BaseService();
    private MovieDatabase movieDatabase = new MovieDatabase();

    @FXML
    private TableView<Movie> tableViewManagement;

    @FXML
    private TableColumn<Movie, LocalDateTime> startColumn;

    @FXML
    private TableColumn<Movie, LocalDateTime> endColumn;

    @FXML
    private TableColumn<Movie, String> titleColumn;

    @FXML
    private TableColumn<Movie, Integer> seatsLeftColumn;

    @FXML
    private Button addShowingsButton;

    @FXML
    private Button buttonSellTickets;


    private void changeView(Button button, String view, BaseController controller, String title){
        try{
            Stage viewStage = (Stage) button.getScene().getWindow();
            viewStage.close();

            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(view));
            fxmlLoader.setController(controller);

            Parent root = fxmlLoader.load();

            Stage newViewStage = new Stage();
            newViewStage.setTitle(title);
            newViewStage.setScene(new Scene(root));
            newViewStage.show();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        startColumn.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        endColumn.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        seatsLeftColumn.setCellValueFactory(new PropertyValueFactory<>("seatsLeft"));

        movieDatabase.load();
        List<Movie> movieList = movieDatabase.getMovies();
        ObservableList<Movie> movies = FXCollections.observableArrayList(movieList);
        tableViewManagement.setItems(movies);

        //1.0
//        ObservableList<Movie> movies = manageShowingService.readMovies();
//        tableViewManagement.setItems(movies);

        addShowingsButton.setOnAction(event -> {changeView(addShowingsButton, "addshowing-view.fxml", new AddShowingController(), "Add Showing");});
        buttonSellTickets.setOnAction(event -> changeView(buttonSellTickets, "selltickets-view.fxml", new SellTicketsController(), "Sell Tickets"));
    }
}
