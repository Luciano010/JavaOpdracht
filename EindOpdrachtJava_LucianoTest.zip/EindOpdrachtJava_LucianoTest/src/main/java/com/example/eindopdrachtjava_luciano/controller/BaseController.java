package com.example.eindopdrachtjava_luciano.controller;

public interface BaseController {

}
