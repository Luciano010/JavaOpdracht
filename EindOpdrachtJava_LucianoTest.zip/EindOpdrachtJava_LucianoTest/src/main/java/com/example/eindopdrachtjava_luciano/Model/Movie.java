package com.example.eindopdrachtjava_luciano.Model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Movie implements Serializable {
    //private static final long serialVersionUID = 1L;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String title;
    private int seatsLeft;

    public Movie(LocalDateTime startTime, LocalDateTime endTime, String title, int seatsLeft) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.title = title;
        this.seatsLeft = seatsLeft;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getTitle() { //getter
        return title;
    }

    public void setTitle(String title) { //setter
        this.title = title;
    }

    public int getSeatsLeft() {
        return seatsLeft;
    }

    public void setSeatsLeft(int seatsLeft) {
        this.seatsLeft = seatsLeft;
    }
}
