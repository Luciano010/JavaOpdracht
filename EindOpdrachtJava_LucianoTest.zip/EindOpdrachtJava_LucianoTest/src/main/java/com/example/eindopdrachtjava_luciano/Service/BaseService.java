package com.example.eindopdrachtjava_luciano.Service;

import com.example.eindopdrachtjava_luciano.Model.Movie;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class BaseService {
    private ObservableList<Movie> movieList = FXCollections.observableArrayList();

    public BaseService() {

    }

    private static final String fileName = "C:/Users/Beheerder/IdeaProjects/EindOpdrachtJava_Luciano/src/main/java/com/example/eindopdrachtjava_luciano/DAL/movies.dat";

    public ObservableList<Movie> readMovies() {
        List<Movie> movieList = new ArrayList<>();

        File file = new File(fileName);
        if (!file.exists() || file.length() == 0) {
            return FXCollections.observableArrayList(movieList);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            movieList = (List<Movie>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return FXCollections.observableArrayList(movieList);
    }
}
