package com.example.eindopdrachtjava_luciano.DAL;

import com.example.eindopdrachtjava_luciano.Model.User;

import java.util.ArrayList;

public class UserDao {
    private ArrayList<User> users;

    public UserDao() {
        users = new ArrayList<>();
    }


}
