package com.example.eindopdrachtjava_luciano.controller;

import com.example.eindopdrachtjava_luciano.HelloApplication;
import com.example.eindopdrachtjava_luciano.Model.User;
import com.example.eindopdrachtjava_luciano.Service.UserService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label labelChange;

    @FXML
    private Button loginButton;

    UserService userService = new UserService();

    @FXML
    private void onLoginButtonClick() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = userService.authenticate(username, password);
        if (user != null) {
            try {
                Stage loginStage = (Stage) loginButton.getScene().getWindow();
                loginStage.close();

                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("dashboard-view.fxml"));
                DashboardController dashboardController = new DashboardController(user);
                fxmlLoader.setController(dashboardController);

                Parent root = fxmlLoader.load();

                Stage dashboardStage = new Stage();
                dashboardStage.setTitle("Dashboard");
                dashboardStage.setScene(new Scene(root));
                dashboardStage.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else {
            labelChange.setText("Invalid username/password combination.");
        }
    }
}
