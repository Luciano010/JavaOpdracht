module com.example.eindopdrachtjava_luciano {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.logging;


    opens com.example.eindopdrachtjava_luciano to javafx.fxml;
    opens com.example.eindopdrachtjava_luciano.Model to javafx.base;
    exports com.example.eindopdrachtjava_luciano;
    exports com.example.eindopdrachtjava_luciano.controller;
    opens com.example.eindopdrachtjava_luciano.controller to javafx.fxml;
}